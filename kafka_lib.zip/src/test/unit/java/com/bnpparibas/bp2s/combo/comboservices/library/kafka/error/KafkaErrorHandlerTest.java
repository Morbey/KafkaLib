package com.bnpparibas.bp2s.combo.comboservices.library.kafka.error;

import com.bnpparibas.bp2s.combo.comboservices.library.kafka.config.KafkaConsumerErrorProperties;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.core.KafkaGenericPublisher;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.model.GenericKafkaMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class KafkaErrorHandlerTest {

    private KafkaGenericPublisher<GenericKafkaMessage> publisher;
    private KafkaConsumerErrorProperties properties;
    private KafkaErrorMapper<GenericKafkaMessage> mapper;
    private KafkaErrorHandler<GenericKafkaMessage> errorHandler;

    @BeforeEach
    void setUp() {
        publisher = mock(KafkaGenericPublisher.class);
        properties = new KafkaConsumerErrorProperties();
        properties.setMaxAttempts(3);
        properties.setRetryInterval(10);
        mapper = (message, ex) -> GenericKafkaMessage.builder()
                .messageType("DLQ")
                .status("FAILED")
                .originalMessage(message.getPayload().toString())
                .topicName("original-topic")
                .payload(message.getPayload())
                .errorMsg(ex.getMessage())
                .build();

        errorHandler = new KafkaErrorHandler<>(publisher, properties, mapper);
    }

    @Test
    void shouldThrowExceptionAndRetryIfAttemptsNotExceeded() {
        Message<String> message = MessageBuilder.withPayload("test")
                .setHeader("X-Retry-Attempt", 0)
                .build();

        assertThrows(RuntimeException.class, () -> errorHandler.handleError(message, new RuntimeException("fail")));
    }

    @Test
    void shouldSendToDlqAfterMaxRetries() {
        Message<String> message = MessageBuilder.withPayload("payload")
                .setHeader("X-Retry-Attempt", 2)
                .build();

        errorHandler.handleError(message, new RuntimeException("retry failed"));

        verify(publisher, times(1)).publish(eq(""), any(GenericKafkaMessage.class));
    }
}
