package com.bnpparibas.bp2s.combo.comboservices.library.kafka.util;

import org.junit.jupiter.api.Test;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class KafkaHeaderUtilsTest {

    @Test
    void shouldExtractHeaderValues() {
        Message<String> message = MessageBuilder.withPayload("payload")
                .setHeader("X-Message-Type", "TEST")
                .setHeader("X-Status", "SUCCESS")
                .setHeader("X-Original-Topic", "topic")
                .build();

        assertEquals(Optional.of("TEST"), KafkaHeaderUtils.getMessageType(message));
        assertEquals(Optional.of("SUCCESS"), KafkaHeaderUtils.getStatus(message));
        assertEquals(Optional.of("topic"), KafkaHeaderUtils.getOriginalTopic(message));
    }

    @Test
    void shouldReturnEmptyIfHeaderMissing() {
        Message<String> message = MessageBuilder.withPayload("payload").build();

        assertTrue(KafkaHeaderUtils.getMessageType(message).isEmpty());
        assertTrue(KafkaHeaderUtils.getStatus(message).isEmpty());
        assertTrue(KafkaHeaderUtils.getOriginalTopic(message).isEmpty());
    }
}
