package com.bnpparibas.bp2s.combo.comboservices.library.kafka.context;

import org.junit.jupiter.api.Test;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import static org.junit.jupiter.api.Assertions.assertEquals;

class KafkaRetryContextTest {

    @Test
    void shouldIncrementRetryHeader() {
        Message<String> original = MessageBuilder.withPayload("test")
                .setHeader("X-Retry-Attempt", 1)
                .build();

        int retry = KafkaRetryContext.incrementAndGetRetryAttempt(original);
        assertEquals(2, retry);
    }

    @Test
    void shouldDefaultToOneIfHeaderMissing() {
        Message<String> original = MessageBuilder.withPayload("test").build();
        int retry = KafkaRetryContext.incrementAndGetRetryAttempt(original);
        assertEquals(1, retry);
    }
}
