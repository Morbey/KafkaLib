package com.bnpparibas.bp2s.combo.comboservices.library.kafka.core;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

class KafkaGenericPublisherTest {

    private KafkaTemplate<String, String> kafkaTemplate;
    private KafkaGenericPublisher<String> publisher;

    @BeforeEach
    void setUp() {
        kafkaTemplate = Mockito.mock(KafkaTemplate.class);
        publisher = new KafkaGenericPublisher<>(kafkaTemplate);
    }

    @Test
    void shouldSendMessageToKafka() {
        @SuppressWarnings("unchecked")
        CompletableFuture<SendResult<String, String>> future = mock(CompletableFuture.class);
        when(kafkaTemplate.send("test-topic", "hello")).thenReturn(future);

        assertDoesNotThrow(() -> publisher.publish("test-topic", "hello"));

        verify(kafkaTemplate, times(1)).send("test-topic", "hello");
        verify(future, times(1)).whenComplete(any());
    }
}
