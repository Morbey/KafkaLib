package com.bnpparibas.bp2s.combo.comboservices.library.kafka;

import com.bnpparibas.bp2s.combo.comboservices.library.kafka.config.KafkaConsumerErrorProperties;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.core.KafkaGenericPublisher;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.error.KafkaErrorHandler;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.error.KafkaErrorMapper;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.model.GenericKafkaMessage;
import org.junit.jupiter.api.Test;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import static org.mockito.Mockito.*;

class KafkaErrorIntegrationTest_MapperThrowsException {

    @Test
    void shouldHandleMapperExceptionGracefully() {
        KafkaGenericPublisher<GenericKafkaMessage> publisher = mock(KafkaGenericPublisher.class);
        KafkaConsumerErrorProperties props = new KafkaConsumerErrorProperties();
        props.setMaxAttempts(3);

        KafkaErrorMapper<GenericKafkaMessage> mapper = (msg, ex) -> {
            throw new RuntimeException("Mapper failed");
        };

        KafkaErrorHandler<GenericKafkaMessage> handler = new KafkaErrorHandler<>(publisher, props, mapper);

        Message<String> message = MessageBuilder
                .withPayload("message")
                .setHeader("X-Retry-Attempt", 3)
                .build();

        handler.handleError(message, new RuntimeException("original failure"));

        verify(publisher, never()).publish(any(), any());
    }
}
