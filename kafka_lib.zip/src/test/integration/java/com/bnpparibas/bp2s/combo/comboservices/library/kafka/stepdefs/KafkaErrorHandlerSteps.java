package com.bnpparibas.bp2s.combo.comboservices.library.kafka.stepdefs;

import com.bnpparibas.bp2s.combo.comboservices.library.kafka.config.KafkaConsumerErrorProperties;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.core.KafkaGenericPublisher;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.error.KafkaErrorHandler;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.error.KafkaErrorMapper;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.model.GenericKafkaMessage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import static org.mockito.Mockito.*;

public class KafkaErrorHandlerSteps {

    private KafkaGenericPublisher<GenericKafkaMessage> publisher;
    private KafkaErrorHandler<GenericKafkaMessage> handler;
    private Message<String> testMessage;

    @Given("a message without retry headers")
    public void messageWithoutRetryHeaders() {
        setupHandler(3);
        testMessage = MessageBuilder.withPayload("no header").build();
    }

    @Given("a message with retry count {int} and maxAttempts is {int}")
    public void messageWithRetryCountAndMaxAttempts(int retry, int max) {
        setupHandler(max);
        testMessage = MessageBuilder.withPayload("payload").setHeader("X-Retry-Attempt", retry).build();
    }

    @Given("a message with retry count {int} and a mapper that throws exception")
    public void messageWithRetryCountAndMapperFails(int retry) {
        publisher = mock(KafkaGenericPublisher.class);
        KafkaConsumerErrorProperties props = new KafkaConsumerErrorProperties();
        props.setMaxAttempts(3);
        KafkaErrorMapper<GenericKafkaMessage> faultyMapper = (msg, ex) -> { throw new RuntimeException("Mapper error"); };
        handler = new KafkaErrorHandler<>(publisher, props, faultyMapper);
        testMessage = MessageBuilder.withPayload("x").setHeader("X-Retry-Attempt", retry).build();
    }

    @When("it is handled by the error handler")
    public void itIsHandledByHandler() {
        handler.handleError(testMessage, new RuntimeException("forced error"));
    }

    @Then("it should not be published to DLQ")
    public void itShouldNotPublish() {
        verify(publisher, never()).publish(any(), any());
    }

    private void setupHandler(int maxAttempts) {
        publisher = mock(KafkaGenericPublisher.class);
        KafkaConsumerErrorProperties props = new KafkaConsumerErrorProperties();
        props.setMaxAttempts(maxAttempts);
        KafkaErrorMapper<GenericKafkaMessage> mapper = (msg, ex) -> GenericKafkaMessage.builder()
                .payload(msg.getPayload())
                .errorMsg(ex.getMessage())
                .build();
        handler = new KafkaErrorHandler<>(publisher, props, mapper);
    }
}
