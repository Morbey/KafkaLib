package com.bnpparibas.bp2s.combo.comboservices.library.kafka;

import com.bnpparibas.bp2s.combo.comboservices.library.kafka.config.KafkaConsumerErrorProperties;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.core.KafkaGenericPublisher;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.error.KafkaErrorHandler;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.error.KafkaErrorMapper;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.model.GenericKafkaMessage;
import org.junit.jupiter.api.Test;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import static org.mockito.Mockito.*;

class KafkaErrorIntegrationTest_NoHeader {

    @Test
    void shouldNotFailIfRetryHeaderMissing() {
        KafkaGenericPublisher<GenericKafkaMessage> publisher = mock(KafkaGenericPublisher.class);
        KafkaConsumerErrorProperties props = new KafkaConsumerErrorProperties();
        props.setMaxAttempts(3);

        KafkaErrorMapper<GenericKafkaMessage> mapper = (msg, ex) -> GenericKafkaMessage.builder()
                .payload(msg.getPayload())
                .errorMsg(ex.getMessage())
                .build();

        KafkaErrorHandler<GenericKafkaMessage> handler = new KafkaErrorHandler<>(publisher, props, mapper);

        Message<String> message = MessageBuilder.withPayload("message with no header").build();

        handler.handleError(message, new RuntimeException("no header error"));

        verify(publisher, never()).publish(any(), any());
    }
}
