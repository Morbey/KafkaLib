package com.bnpparibas.bp2s.combo.comboservices.library.kafka.headers;

/**
 * Kafka header keys used internally across the library.
 */
public enum KafkaHeaderKeys {
    MESSAGE_TYPE,
    STATUS,
    ORIGINAL_TOPIC
}
