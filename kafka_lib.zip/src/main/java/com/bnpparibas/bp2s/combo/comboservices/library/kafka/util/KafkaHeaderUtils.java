package com.bnpparibas.bp2s.combo.comboservices.library.kafka.util;

import com.bnpparibas.bp2s.combo.comboservices.library.kafka.headers.KafkaHeaderKeys;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;

import java.util.Optional;

/**
 * Utility class for reading headers safely from Kafka messages.
 */
public final class KafkaHeaderUtils {

    private KafkaHeaderUtils() {}

    public static Optional<String> getMessageType(Message<?> message) {
        return getHeaderAsString(message.getHeaders(), KafkaHeaderKeys.MESSAGE_TYPE.name());
    }

    public static Optional<String> getStatus(Message<?> message) {
        return getHeaderAsString(message.getHeaders(), KafkaHeaderKeys.STATUS.name());
    }

    public static Optional<String> getOriginalTopic(Message<?> message) {
        return getHeaderAsString(message.getHeaders(), KafkaHeaderKeys.ORIGINAL_TOPIC.name());
    }

    private static Optional<String> getHeaderAsString(MessageHeaders headers, String key) {
        Object value = headers.get(key);
        return value != null ? Optional.of(value.toString()) : Optional.empty();
    }
}
