package com.bnpparibas.bp2s.combo.comboservices.library.kafka.model;

import lombok.Builder;
import lombok.Value;
import org.springframework.messaging.MessageHeaders;

import java.time.Instant;

/**
 * Generic structure to wrap error/failure messages to be sent to DLQs or log repositories.
 */
@Value
@Builder
public class GenericKafkaMessage {
    String messageType;
    String topicName;
    String originalMessage;
    MessageHeaders headers;
    Object payload;
    String status;
    Instant createdAt;
    String errorMsg;
    String objectMsgId;
}
