package com.bnpparibas.bp2s.combo.comboservices.library.kafka.error;

import com.bnpparibas.bp2s.combo.comboservices.library.kafka.config.KafkaConsumerErrorProperties;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.context.KafkaRetryContext;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.core.KafkaGenericPublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.Message;

@Slf4j
@RequiredArgsConstructor
public class KafkaErrorHandler<T> {

    private final KafkaGenericPublisher<T> publisher;
    private final KafkaConsumerErrorProperties properties;
    private final KafkaErrorMapper<T> errorMapper;

    /**
     * Handles a Kafka message failure. Retries if allowed, otherwise publishes to fallback topic.
     *
     * @param message   the original failed message
     * @param exception the exception that occurred
     */
    public void handleError(Message<?> message, Exception exception) {
        int attempt = KafkaRetryContext.incrementAndGetRetryAttempt(message);
        log.debug("Handling error on attempt {}: {}", attempt, exception.getMessage());

        if (attempt < properties.getMaxAttempts()) {
            try {
                Thread.sleep(properties.getRetryInterval());
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            throw new RuntimeException(exception);
        }

        log.error("Max retry attempts reached. Publishing to fallback topic...");

        T errorMessage = errorMapper.buildErrorMessage(message, exception);
        publisher.publish(properties.getDlqTopicName(), errorMessage);
    }
}
