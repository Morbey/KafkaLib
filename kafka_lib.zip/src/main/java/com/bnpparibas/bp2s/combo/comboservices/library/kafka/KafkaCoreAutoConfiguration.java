package com.bnpparibas.bp2s.combo.comboservices.library.kafka;

import com.bnpparibas.bp2s.combo.comboservices.library.kafka.config.KafkaConsumerErrorProperties;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.core.KafkaGenericPublisher;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.error.KafkaErrorHandler;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.error.KafkaErrorMapper;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.model.GenericKafkaMessage;
import com.bnpparibas.bp2s.combo.comboservices.library.kafka.util.KafkaHeaderUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;

import java.time.Instant;

/**
 * Autoconfiguration for Kafka core components including DLQ handling.
 */
@Configuration
@EnableConfigurationProperties(KafkaConsumerErrorProperties.class)
public class KafkaCoreAutoConfiguration {

    @Bean
    public KafkaGenericPublisher<GenericKafkaMessage> kafkaGenericPublisher(
            KafkaTemplate<String, GenericKafkaMessage> kafkaTemplate
    ) {
        return new KafkaGenericPublisher<>(kafkaTemplate);
    }

    @Bean
    @ConditionalOnMissingBean
    public KafkaErrorMapper<GenericKafkaMessage> defaultKafkaErrorMapper() {
        return (message, exception) -> GenericKafkaMessage.builder()
                .messageType(KafkaHeaderUtils.getMessageType(message).orElse("UNKNOWN"))
                .status(KafkaHeaderUtils.getStatus(message).orElse("FAILED"))
                .originalMessage(message.getPayload().toString())
                .topicName(KafkaHeaderUtils.getOriginalTopic(message).orElse("unknown"))
                .headers(message.getHeaders())
                .payload(message.getPayload())
                .errorMsg(exception.getMessage())
                .createdAt(Instant.now())
                .objectMsgId(message.getHeaders().getId() != null ? message.getHeaders().getId().toString() : null)
                .build();
    }

    @Bean
    @ConditionalOnMissingBean
    public KafkaErrorHandler<GenericKafkaMessage> kafkaErrorHandler(
            KafkaGenericPublisher<GenericKafkaMessage> publisher,
            KafkaConsumerErrorProperties properties,
            KafkaErrorMapper<GenericKafkaMessage> errorMapper
    ) {
        return new KafkaErrorHandler<>(publisher, properties, errorMapper);
    }
}
