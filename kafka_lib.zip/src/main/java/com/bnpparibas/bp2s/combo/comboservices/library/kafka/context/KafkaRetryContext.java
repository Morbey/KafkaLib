package com.bnpparibas.bp2s.combo.comboservices.library.kafka.context;

import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;

/**
 * Manages retry attempts using message headers.
 */
public final class KafkaRetryContext {

    private static final String RETRY_ATTEMPT_HEADER = "X-Retry-Attempt";

    private KafkaRetryContext() {
    }

    public static int incrementAndGetRetryAttempt(Message<?> message) {
        int current = getCurrentAttempt(message);
        return current + 1;
    }

    public static int getCurrentAttempt(Message<?> message) {
        MessageHeaders headers = message.getHeaders();
        Object header = headers.get(RETRY_ATTEMPT_HEADER);
        if (header instanceof Integer) return (Integer) header;
        if (header instanceof String) return Integer.parseInt((String) header);
        return 0;
    }
}
