package com.bnpparibas.bp2s.combo.comboservices.library.kafka.core;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.MessageHeaders;

/**
 * Generic Kafka message publisher. Can be reused for publishing any message, including to DLQs.
 */
@Slf4j
@RequiredArgsConstructor
public class KafkaGenericPublisher<T> {

    private final KafkaTemplate<String, T> kafkaTemplate;

    public void publish(String topic, T message) {
        log.debug("Publishing message to topic [{}] with payload [{}]", topic, message);
        kafkaTemplate.send(topic, message);
    }
}

